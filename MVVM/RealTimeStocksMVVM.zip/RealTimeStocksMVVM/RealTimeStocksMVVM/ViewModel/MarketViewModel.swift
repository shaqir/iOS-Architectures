//
//  MarketViewModel.swift
//  RealTimeStocksMVVM
//
//  Created by Sakir Saiyed on 2025-06-26.
//

import SwiftUI
import Combine

class MarketViewModel: ObservableObject {
    @Published var visibleStocks: [StockViewData] = []

    private var cancellables = Set<AnyCancellable>()
    private let interactor: MarketUseCase

    init(interactor: MarketUseCase) {
        self.interactor = interactor
        bind()
        interactor.start()
    }

    deinit {
        interactor.stop()
    }

    private func bind() {
        interactor.publisher
            .receive(on: RunLoop.main)
            .sink { [weak self] in self?.visibleStocks = $0 }
            .store(in: &cancellables)
    }
}
