//
//  StockViewData.swift
//  RealTimeStocksMVVM
//
//  Created by Sakir Saiyed on 2025-06-26.
//

import Foundation
// MARK: - ViewModel Adapter

struct StockViewData: Identifiable {
    let id = UUID()
    let symbol: String
    let price: String
    let isPriceUp: Bool

    init(stock: Stock) {
        self.symbol = stock.symbol
        self.price = String(format: "%.2f", stock.price)
        self.isPriceUp = stock.isPriceUp
    }
}

