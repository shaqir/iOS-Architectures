//
//  RealTimeStocksMVVMApp.swift
//  RealTimeStocksMVVM
//
//  Created by Sakir Saiyed on 2025-06-26.
//

import SwiftUI

@main
struct RealTimeStocksMVVMApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
