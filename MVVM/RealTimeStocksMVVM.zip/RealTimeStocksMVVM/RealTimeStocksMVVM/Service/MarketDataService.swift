//
//  MarketDataService.swift
//  RealTimeStocksMVVM
//
//  Created by Sakir Saiyed on 2025-06-26.
//

import SwiftUI
import Combine
// MARK: - Data Layer (Mock WebSocket)

protocol MarketDataProviding {
    var tickerStream: PassthroughSubject<[Stock], Never> { get }
    func connect()
    func disconnect()
}

class MarketDataService: MarketDataProviding {
    
    
    let tickerStream = PassthroughSubject<[Stock], Never>()
    private var cancellables = Set<AnyCancellable>()
    private let symbols = ["AAPL", "GOOG", "TSLA"]
    private let apiKey = "814b5552f85243c59505e3443acbeb38"
    private var timer: Timer?
    private let popularSymbols = ["AAPL", "MSFT", "AMZN", "GOOG", "TSLA",
                                   "META", "NVDA", "NFLX", "AMD", "JPM"]
    
    func connect() {
            timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
                let stocks = self.popularSymbols.map { symbol in
                    Stock(
                        symbol: symbol,
                        price: Double.random(in: 100...900),
                        isPriceUp: Bool.random()
                    )
                }
                self.tickerStream.send(stocks)
            }
        }

    func fetchLivePrices() {
        let group = DispatchGroup()
        var stocks: [Stock] = []

        for symbol in symbols {
            group.enter()
            let urlStr = "https://api.twelvedata.com/price?symbol=\(symbol)&apikey=\(apiKey)"
            guard let url = URL(string: urlStr) else { group.leave(); continue }

            URLSession.shared.dataTask(with: url) { data, _, _ in
                defer { group.leave() }
                if let data = data,
                   let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let priceStr = json["price"] as? String,
                   let price = Double(priceStr) {
                    let stock = Stock(symbol: symbol, price: price, isPriceUp: Bool.random())
                    stocks.append(stock)
                }
            }.resume()
        }

        group.notify(queue: .main) {
            self.tickerStream.send(stocks)
        }
    }
    func disconnect() {
            timer?.invalidate()
            timer = nil
        }
    
}
