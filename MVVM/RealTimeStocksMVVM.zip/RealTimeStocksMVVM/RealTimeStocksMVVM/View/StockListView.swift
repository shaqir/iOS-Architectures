//
//  StockListView.swift
//  RealTimeStocksMVVM
//
//  Created by Sakir Saiyed on 2025-06-26.
//

import SwiftUI
import Combine

// MARK: - View

struct StockListView: View {
    @ObservedObject var viewModel: MarketViewModel

    var body: some View {
        NavigationView {
            List(viewModel.visibleStocks) { stock in
                HStack {
                    Text(stock.symbol)
                        .bold()
                    Spacer()
                    Text("$\(stock.price)")
                        .foregroundColor(stock.isPriceUp ? .green : .red)
                }
            }
            .navigationTitle("📈 Stocks Live")
        }
    }
}
