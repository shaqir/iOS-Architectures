//
//  ContentView.swift
//  RealTimeStocksMVVM
//
//  Created by Sakir Saiyed on 2025-06-26.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        let service = MarketDataService()
        let interactor = MarketInteractor(service: service)
        let viewModel = MarketViewModel(interactor: interactor)
        StockListView(viewModel: viewModel)
    }
}

#Preview {
    ContentView()
}
